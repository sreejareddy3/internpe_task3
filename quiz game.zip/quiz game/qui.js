// Define your quiz questions and answers here
const quizQuestions = [
  {
    question: "What is the capital of France?",
    options: ["Paris", "Madrid", "London", "Rome"],
    answer: "Paris"
  },
  {
    question: "Which planet is known as the Red Planet?",
    options: ["Mars", "Venus", "Mercury", "Jupiter"],
    answer: "Mars"
  },
  // Add more questions as needed
];

let currentQuestion = 0;
let score = 0;

const questionElement = document.getElementById("question");
const optionsElement = document.getElementById("options");
const submitButton = document.getElementById("submit-btn");

function loadQuestion() {
  const question = quizQuestions[currentQuestion];
  questionElement.textContent = question.question;

  optionsElement.innerHTML = "";
  for (let option of question.options) {
    const li = document.createElement("li");
    const radio = document.createElement("input");
    radio.type = "radio";
    radio.name = "answer";
    radio.value = option;
    li.appendChild(radio);
    li.appendChild(document.createTextNode(option));
    optionsElement.appendChild(li);
  }
}

function submitAnswer() {
  const selectedOption = document.querySelector('input[name="answer"]:checked');
  if (!selectedOption) {
    alert("Please select an option");
    return;
  }

  const answer = selectedOption.value;
  if (answer === quizQuestions[currentQuestion].answer) {
    score++;
  }

  currentQuestion++;
  if (currentQuestion < quizQuestions.length) {
    loadQuestion();
  } else {
    showResult();
  }
}

function showResult() {
  questionElement.textContent = `You have completed the quiz! Your score is ${score}/${quizQuestions.length}`;
  optionsElement.innerHTML = "";
  submitButton.style.display = "none";
}

// Event listeners
submitButton.addEventListener("click", submitAnswer);

// Load the first question
loadQuestion();
